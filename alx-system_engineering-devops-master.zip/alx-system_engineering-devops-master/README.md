A readme for the shell basics project
project


0. script thatswitches currrent user to betty
1. script that prints effective username
2. script that prints all the groups user is part of 
3. script that changes owner of file 
4. script that creates an empty file
5. script that adds exccecute permissions 
6. scriot that add execute permissions to owner and group owner and read perm. to others
7. script that adds execution perm to everyone
8. script that sets file perm to ..
9. script that sets mod of file to 
10. script that mode of file same as olleh mode
11. script that excecute permision to all subdir in curr dir.
12. script that creates a dir with permission 751
13. script that changes the group owner to sch for ffile hello 
14.

Shell input/output redirections and filter 
0 - a script that prints "hello world" followed by new line to stdout


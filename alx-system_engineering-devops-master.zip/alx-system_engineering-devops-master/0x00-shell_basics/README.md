0-current_working _directory contains a script that prints currret working directory
2. 1-listit displays the contents list of a current directory
3. 2-bring_me_home is a script that changes the working directory to the user’s home directory
4. script that Display current directory contents in a long format
5. DIspplay current dir content